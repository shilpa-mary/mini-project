# # forms.py
# from django import forms
# from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
# from .models import CustomUser
#  {{ form.name }}
# # class CustomUserCreationForm(UserCreationForm):
# #     class Meta:
# #         model = CustomUser
# #         fields = ( 'email' 'password')

# class CustomAuthenticationForm(AuthenticationForm):
#     class Meta:
#         model = CustomUser
#         fields = ['emailpassword']
       
#         widgets = {
#             'email': TextInput(attrs={
#                 'class': "form-control",
#                 'style': 'max-width: 300px;',
#                 'placeholder': 'Name',
               
#                 }),
#             'password': EmailInput(attrs={
#                 'class': "form-control", 
#                 'style': 'max-width: 300px;',
#                 'placeholder': 'password',
               
#                 })
#         }
