from django.db import models

from django.contrib.auth.models import AbstractUser
from django.db import models

class CustomUser(AbstractUser):
    role = models.CharField(max_length=15, blank=True, null=True)

class UserData(models.Model):
    first_name = models.CharField(max_length=150)
    last_name = models.CharField(max_length=150,null=True)
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=150)
    role = models.CharField(max_length=15, blank=True, null=True)

    