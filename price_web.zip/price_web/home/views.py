from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib.auth.forms import AuthenticationForm
from django.http import HttpResponse
from .models import UserData
from django.contrib import messages


def index(request):
    return render(request,'index.html')

def aboutUs(request):
    return render(request,'moreinfo.html')
    
    
def register(request):
    if 'user_id' in request.session :
        return redirect('index')
    if request.method == 'POST':
        if(request.POST['email']=='' or request.POST['first_name']==''or request.POST['password']==''):
            messages.success(request, 'Invalid Data')
            return redirect('login') 
        oldUser = UserData.objects.filter(email=request.POST['email']).first() 
        if oldUser != None:
           messages.success(request, 'Email already taken')
           return redirect('login') 
        user =  UserData();
        user.email= request.POST['email']
        user.first_name =  request.POST['first_name']
        user.last_name =  request.POST['last_name']
        user.password = request.POST['password']
        user.role= 'user'
        user.save()
        request.session['user_name'] = user.first_name
        request.session['user_id'] = user.id
        return redirect('index')
        
def logout(request):
    if 'user_id' in request.session :
        del request.session['user_id'] 
        del request.session['user_name']
    return redirect('index')
    
def user_login(request):
    if 'user_id' in request.session :
        return redirect('index')
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['password']
        user = UserData.objects.filter(email=email, password=password).first()
        # print(user);
        if user != None:
            request.session['user_name'] = user.first_name
            request.session['user_id'] = user.id
            return redirect('index')
        else:
            messages.success(request, 'Incorrect Email/Password')
            return redirect('login')
            
    else:
        return render(request, 'login.html')

def profile(request):
    if 'user_id' in request.session : 
        user = UserData.objects.filter(id=request.session['user_id']).first() 
        if request.method == 'POST':
            if request.POST['first_name']!='':
                user.first_name = request.POST['first_name']
            user.last_name = request.POST['last_name']
            if request.POST['password']!='':
                user.password = request.POST['password']
            user.save()
            messages.success(request, 'Profile Updated')
            return redirect('profile')
        return render(request,'profile.html',{'user':user})
    return redirect('login')