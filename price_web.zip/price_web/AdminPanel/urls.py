from django.urls import path

from . import views

urlpatterns = [
     path('',views.index,name='adminHome'),
     path('/login',views.login,name='adminLogin'),
     path('/logout',views.logout,name='adminLogout'),
     path('/users',views.adminUserList,name='adminUserList'),
     path('/url',views.adminUrlList,name='adminUrlList'),
     
]