from django.shortcuts import render,redirect
from home.models import UserData
from  products.models import UrlCount
from django.contrib import messages
# Create your views here.
def index(request):
    if 'user_id' in request.session and 'user_role' in request.session  :
       return render(request,'adminhome.html')
    return redirect('adminLogin')

def login(request):
    if 'user_id' in request.session and 'user_role' in request.session  :
        return redirect('adminHome')
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['password']
        user = UserData.objects.filter(email=email, password=password).first()
        if user != None and user.role =='admin':
            request.session['user_name'] = user.first_name
            request.session['user_id'] = user.id
            request.session['user_role'] = user.role
            return redirect('adminHome')
        else:
            messages.success(request, 'Incorrect Email/Password')
            return redirect('adminLogin')
                
    else:
        return render(request, 'admin-login.html')

def logout(request):
    if 'user_id' in request.session and 'user_role' in request.session  :
        del request.session['user_id'] 
        del request.session['user_name']
        del request.session['user_role']         
    return redirect('index')

def adminUserList(request):
    if 'user_id' in request.session and 'user_role' in request.session:
        users = UserData.objects.filter(role='user').all()
        return render(request,'user_list.html',{'users':users}) 
    return redirect('adminLogin')    

def adminUrlList(request):
    if 'user_id' in request.session and 'user_role' in request.session  :
        amazonCount = UrlCount.objects.filter(platform='amazon').count()
        flipKartCount = UrlCount.objects.filter(platform='flipkart').count()
        cromaCount = UrlCount.objects.filter(platform='croma').count()
        return render(request,'url-count.html',{'amazon':amazonCount,'croma':cromaCount,'flipkart':flipKartCount})
    return redirect('adminLogin')    
    
    