from django.shortcuts import render,redirect
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from bs4 import BeautifulSoup
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from  .models import Favorite,History,UrlCount

def index(request):
    historyList = [] 
    if 'user_id' in request.session : 
        historyList = History.objects.filter(user_id=request.session['user_id']).all().order_by('-id')[:12]     
    return render(request,'list.html',{'historyList':historyList})

@require_POST
def productList(request):
    
     # Set up Chrome options for headless mode
    chrome_options = Options()
    chrome_options.add_argument('--headless')
    chrome_options.add_argument('--disable-gpu')  # Required for headless mode

    # Set up the Chrome driver with the specified options
    driver = webdriver.Chrome(options=chrome_options)
    search = request.POST['search']
    if 'user_id' in request.session and search !='' and not History.objects.filter(search=search).exists() : 
        history = History()
        history.user_id = request.session['user_id'] 
        history.search = search
        history.save()
    url ='https://www.smartprix.com/products/?q='+search
    driver.get(url)
    page = driver.execute_script('return document.body.innerHTML')
    soup = BeautifulSoup(''.join(page), 'html.parser')
    # print(soup)
    links = soup.find_all(class_="sm-product has-tag has-features has-actions")
    data = []
   
    for link in links :
        price = link.find(class_="price")
        url = link.find(class_="store")
        image = link.find(class_="sm-img-wrap")
        imageSrc = image.find("img")
        provider = url.find(class_='sm-img')
        nameTag = link.find(class_='name clamp-2')
        proName = nameTag.find('h2')
        nestedData = {
            'price': price.text,
            'url': url.get('href'),
            'image' : imageSrc.get('src'),
            'platform':provider.get('alt') ,
            'name': proName.text     
        }
        data.append(nestedData)
    return JsonResponse({'data': data}) 
    
def favoriteList(request):
    if 'user_id' in request.session : 
        favoriteList = Favorite.objects.filter(user_id=request.session['user_id']).all().order_by('-id')
        return render(request,'fav.html',{'favoriteList':favoriteList})
    return redirect('/')

def favoriteAdd(request):
    if 'user_id' in request.session : 
        url = request.POST['url']
        image = request.POST['image']
        name  = request.POST['name']
        platform =  request.POST['platform']
        review =  request.POST['review']
        price = request.POST['price']
        fav  = Favorite()
        fav.url = url
        fav.image = image
        fav.platform = platform
        fav.name = name
        fav.review = review
        fav.price= price
        fav.user_id = request.session['user_id']
        fav.save()
    return JsonResponse({'message':'success'})       

def favoriteDelete(request):
    if 'user_id' in request.session : 
        id = request.POST['id']
        favorite = Favorite.objects.filter(user_id=request.session['user_id'],id=id).delete()
    return JsonResponse({'message':'success'})       

def platformCount(request):
    platform = request.POST['platform']
    count = UrlCount()
    count.platform = platform
    count.user_id = 1
    count.save()
    return JsonResponse({'message':'success'})  
     
    
    