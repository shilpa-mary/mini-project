from django.urls import path
from . import views

urlpatterns = [
     path('',views.index,name='product'),
     path('/list',views.productList,name='productList'),
     path('/favorite/list',views.favoriteList,name='favoriteList'),
     path('/favorite/add',views.favoriteAdd,name='favoriteAdd'),
     path('/favorite/delete',views.favoriteDelete,name='favoriteDelete'),
     path('/count',views.platformCount,name='platformCount'),
]