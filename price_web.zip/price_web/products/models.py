from django.db import models


# Create your models here.

class Favorite(models.Model):

    user_id = models.IntegerField()
    name = models.TextField(null=True)
    image = models.TextField(null=True)
    review = models.TextField(null=True)
    url = models.TextField(null=True)
    price = models.CharField( max_length=150,null=True)
    platform = models.TextField(null=True)

class UrlCount(models.Model):

    platform = models.TextField(null=True)
    user_id = models.IntegerField()

class History(models.Model):

    search = models.CharField( max_length=150,null=True)
    user_id = models.IntegerField(null=True)        
        